# Messenger Chat Exporter

A small Chrome extension that auto-scrolls a Messenger conversation to the top,
collects the visible text as it goes, and saves the whole thing as a `.txt`
file (and copies it to your clipboard).

## Load it in Chrome

1. Unzip this folder somewhere permanent (don't delete it after installing —
   Chrome loads the extension directly from these files).
2. Open `chrome://extensions`.
3. Turn on **Developer mode** (top-right toggle).
4. Click **Load unpacked** and select this folder.
5. Pin the extension (puzzle-piece icon in the toolbar → pin) so it's easy to reach.

## Use it

1. Go to `messenger.com`, open the conversation you want to export, and scroll
   down so you're at the **most recent message** (the bottom of the chat).
2. Click the extension icon. It asks: *"Είσαι στο κάτω μέρος της συνομιλίας;"*
   ("Are you at the bottom of the chat?"). Click **Ναι** (Yes) once you are —
   if not, click **Όχι** for a reminder to scroll down first.
3. Leave the tab visible while it runs. A red dot appears on the toolbar icon
   the whole time it's working, and the browser will warn you if you try to
   close the tab mid-capture.
4. You can click **Διακοπή** (Stop) at any point — it finishes the batch it's
   currently on and saves everything collected so far, instead of an abrupt cutoff.
5. If you close the popup while it's still running and reopen it later, it
   picks the progress view back up automatically instead of resetting.
6. When it's done (or stopped), you'll get a **browser notification**, a
   `.txt` file downloads automatically (named after you and, where it can
   detect one, the chat partner's name), and buttons appear in the popup:
   **Copy chat**, a full-width **TXT** button (in case you want to re-download
   the default format again), and smaller **JSON** / **HTML** / **CSV** buttons.

## Export formats

- **.txt** (default, auto-downloads and re-downloadable via the TXT button) —
  plain text, one line per message; any images are noted as `[εικόνα] <url>`.
- **JSON** — structured `{ index, text, images[] }` per message, plus chat
  name and export timestamp. Good for feeding into another tool or script.
- **HTML** — a styled, readable transcript with images shown inline. Note:
  the images load directly from Facebook's own CDN links, which are
  time-limited — they may stop displaying after a while, so treat this as a
  snapshot rather than a permanent archive of the images themselves.
- **CSV** — one row per message (`index, text, image_urls`), handy for
  opening in a spreadsheet.

## Built-in reliability

- **Scroll-container auto-recovery**: if Messenger's layout changes mid-run
  (route change, redesign, group vs. 1:1 view), it tries several detection
  strategies and re-attaches instead of silently stalling.
- **Rate-limit backoff**: if Facebook shows a "try again later" style warning,
  the extension pauses (up to 3 times, ~20s each) and resumes automatically
  rather than plowing through or quietly failing.
- **Auto-retry on a dead start**: if the very first attempt collects nothing
  (e.g. the popup was clicked before the page finished loading), it retries
  once automatically before giving up.

## Notes

- This only reads what's rendered on your own screen while you're logged in —
  it doesn't touch Meta's servers directly or access anyone else's account.
- Very long conversations can take a while (it waits for each older batch of
  messages to load before continuing).
- If the popup says the content script wasn't found, refresh the Messenger
  tab once (extensions only attach to tabs opened *after* they're installed)
  and try again.
