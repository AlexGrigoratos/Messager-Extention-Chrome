function setRunningBadge(tabId, running) {
  if (!tabId) return;
  chrome.action.setBadgeBackgroundColor({ tabId, color: '#FF3B30' });
  chrome.action.setBadgeText({ tabId, text: running ? '●' : '' });
}

chrome.runtime.onMessage.addListener((msg, sender) => {
  const tabId = sender.tab && sender.tab.id;

  if (msg.type === 'MC_STARTED' || msg.type === 'MC_PROGRESS') {
    setRunningBadge(tabId, true);
    return;
  }

  if (msg.type === 'MC_DONE' || msg.type === 'MC_ERROR') {
    setRunningBadge(tabId, false);

    if (msg.type === 'MC_DONE') {
      let message;
      if (msg.rateLimited) {
        message = 'Διακόπηκε λόγω περιορισμού από το Facebook — αποθηκεύτηκαν ' + msg.lines + ' γραμμές.';
      } else if (msg.scrollerLost) {
        message = 'Η σελίδα άλλαξε απροσδόκητα — αποθηκεύτηκαν ' + msg.lines + ' γραμμές.';
      } else if (msg.stoppedEarly) {
        message = 'Διακόπηκε από εσένα — αποθηκεύτηκαν ' + msg.lines + ' γραμμές.';
      } else {
        message = 'Ολοκληρώθηκε! Αποθηκεύτηκαν ' + msg.lines + ' γραμμές.';
      }

      chrome.notifications.create({
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'Messenger Chat Exporter',
        message
      });
    }

    return;
  }
});
