(() => {
  const sleep = ms => new Promise(r => setTimeout(r, ms));

  const OWNER_NAME = 'Alexandros Grigoratos';
  const OWNER_FILE_PREFIX = OWNER_NAME.replace(/\s+/g, '-');

  const RATE_LIMIT_PATTERNS = [
    /try again later/i,
    /something went wrong/i,
    /temporarily blocked/i,
    /you'?re doing that too much/i,
    /please wait a few minutes/i,
    /περιμένετε λίγο/i,
    /κάτι πήγε στραβά/i,
    /προσωρινά αποκλεισμένο/i,
    /δοκιμάστε ξανά αργότερα/i
  ];

  const MAX_RATE_LIMIT_BACKOFFS = 3;
  const RATE_LIMIT_BACKOFF_MS = 20000;

  const waitUntilVisible = async () => {
    while (document.visibilityState !== 'visible') {
      await new Promise(resolve => {
        document.addEventListener('visibilitychange', resolve, { once: true });
      });
    }
  };

  function findScrollerHeuristic(root) {
    if (!root) return null;

    const candidates = [...root.querySelectorAll('*')]
      .filter(el => {
        const s = getComputedStyle(el);
        return (
          /(auto|scroll)/.test(s.overflowY) &&
          el.clientHeight > 250 &&
          el.scrollHeight > el.clientHeight + 300
        );
      })
      .sort((a, b) =>
        (b.scrollHeight - b.clientHeight) -
        (a.scrollHeight - a.clientHeight)
      );

    return candidates[0] || null;
  }

  // Tries a few different strategies in case Messenger's DOM structure has
  // shifted (redesign, A/B test, group vs 1:1 chat layout, etc.) instead of
  // relying on a single brittle selector.
  function findScroller() {
    let scroller = findScrollerHeuristic(document.querySelector('[role="main"]'));
    if (scroller) return scroller;

    scroller = findScrollerHeuristic(document.body);
    if (scroller) return scroller;

    const roleLog = document.querySelector('[role="log"], [role="grid"]');
    if (roleLog && roleLog.scrollHeight > roleLog.clientHeight + 100) {
      return roleLog;
    }

    return null;
  }

  // Retries scroller detection a few times with short pauses — covers the
  // case where the popup was clicked before Messenger finished rendering,
  // or the conversation is still loading its first screen.
  async function findScrollerWithRetry(maxAttempts = 6, delayMs = 700) {
    for (let attempt = 0; attempt < maxAttempts; attempt++) {
      const found = findScroller();
      if (found) return found;
      await sleep(delayMs);
    }
    return null;
  }

  // Reads the currently rendered conversation as a list of discrete
  // entries (one per message row where possible) instead of one big text
  // blob — this is what makes structured exports (JSON/HTML/CSV) possible,
  // and lets each entry carry its own image URLs.
  function captureEntries(scroller) {
    const rows = scroller.querySelectorAll('[role="row"]');

    if (rows.length) {
      const entries = [];
      for (const row of rows) {
        const text = (row.innerText || '').trim();
        const imgs = [...row.querySelectorAll('img')]
          .map(img => img.src)
          .filter(src => src && src.startsWith('http'));
        if (text || imgs.length) entries.push({ text, imgs });
      }
      return entries;
    }

    // Fallback if Messenger isn't using role="row" for this view: split the
    // raw text block into lines like the old approach, so de-duplication
    // across snapshots still works. Images can't be reliably tied to a
    // specific line here, so they're appended as trailing entries instead.
    const text = (scroller.innerText || '').trim();
    const entries = text
      .split('\n')
      .map(x => x.trim())
      .filter(Boolean)
      .map(line => ({ text: line, imgs: [] }));

    const looseImgs = [...scroller.querySelectorAll('img')]
      .map(img => img.src)
      .filter(src => src && src.startsWith('http'));

    for (const src of looseImgs) {
      entries.push({ text: '', imgs: [src] });
    }

    return entries;
  }

  function signatureOf(entries) {
    return entries.map(e => e.text + '|' + e.imgs.join(',')).join('\u0001');
  }

  function entriesEqual(a, b) {
    if (a.text !== b.text) return false;
    if (a.imgs.length !== b.imgs.length) return false;
    for (let i = 0; i < a.imgs.length; i++) {
      if (a.imgs[i] !== b.imgs[i]) return false;
    }
    return true;
  }

  function merge(a, b) {
    const max = Math.min(a.length, b.length, 400);

    for (let k = max; k >= 1; k--) {
      let same = true;

      for (let j = 0; j < k; j++) {
        if (!entriesEqual(a[a.length - k + j], b[j])) {
          same = false;
          break;
        }
      }

      if (same) {
        return a.concat(b.slice(k));
      }
    }

    return a.concat(b);
  }

  // Waits until the scroller has genuinely grown/moved AND then stayed
  // put for a short "settle" window — i.e. Messenger has finished
  // rendering that batch of older messages, not just started to.
  async function waitForStableChange(scroller, baselineTop, baselineHeight, maxWaitMs, pollMs = 120, settleMs = 700) {
    const start = Date.now();
    let changedAt = null;
    let lastTop = scroller.scrollTop;
    let lastHeight = scroller.scrollHeight;

    while (Date.now() - start < maxWaitMs) {
      await sleep(pollMs);

      const curTop = scroller.scrollTop;
      const curHeight = scroller.scrollHeight;

      const differsFromBaseline =
        Math.abs(curTop - baselineTop) > 5 || Math.abs(curHeight - baselineHeight) > 20;

      if (differsFromBaseline) {
        if (changedAt === null) changedAt = Date.now();

        const unchangedSincePrevPoll = curTop === lastTop && curHeight === lastHeight;

        if (unchangedSincePrevPoll && Date.now() - changedAt >= settleMs) {
          return true;
        }
      }

      lastTop = curTop;
      lastHeight = curHeight;
    }

    return Math.abs(scroller.scrollTop - baselineTop) > 5 || Math.abs(scroller.scrollHeight - baselineHeight) > 20;
  }

  // Best-effort heuristic: Messenger doesn't expose a documented "you are
  // being rate limited" API, so this looks for common warning text inside
  // alert/status regions of the page.
  function detectRateLimitWarning() {
    const regions = document.querySelectorAll('[role="alert"], [role="status"]');
    for (const el of regions) {
      const text = (el.innerText || '').trim();
      if (!text) continue;
      if (RATE_LIMIT_PATTERNS.some(p => p.test(text))) return true;
    }
    return false;
  }

  function detectChatName() {
    try {
      let title = document.title || '';
      title = title.replace(/^\(\d+\)\s*/, ''); // strip unread-count prefix like "(3) "
      title = title.replace(/\s*[-|·]\s*Messenger\s*$/i, '').trim();
      if (title && title.toLowerCase() !== 'messenger') return title;
    } catch (e) {
      // ignore — fall through to null
    }
    return null;
  }

  function sanitizeForFilename(name, maxLen = 60) {
    return name
      .replace(/[^\p{L}\p{N}\-_. ]/gu, '')
      .trim()
      .replace(/\s+/g, '-')
      .slice(0, maxLen);
  }

  function beforeUnloadHandler(e) {
    e.preventDefault();
    e.returnValue = '';
  }

  function enableUnloadWarning() {
    window.addEventListener('beforeunload', beforeUnloadHandler);
  }

  function disableUnloadWarning() {
    window.removeEventListener('beforeunload', beforeUnloadHandler);
  }

  // Runs one full top-of-conversation sweep. Returns collected snapshots
  // plus flags describing how/why it stopped, so the caller can decide
  // whether to retry, finalize, or report an error.
  async function attemptCapture() {
    let scroller = await findScrollerWithRetry();

    if (!scroller) {
      return { snapshots: [], stoppedEarly: false, rateLimited: false, scrollerLost: false, notFound: true };
    }

    const snapshots = [];
    let noMovementChecks = 0;
    let lastSavedSignature = '';
    let stoppedEarly = false;
    let rateLimited = false;
    let scrollerLost = false;
    let rateLimitHits = 0;

    for (let i = 0; i < 3000 && noMovementChecks < 10; i++) {
      if (window.__MC_STOP_REQUESTED__) {
        stoppedEarly = true;
        break;
      }

      await waitUntilVisible();

      // The scroller element can be replaced entirely if Messenger swaps
      // out the conversation view (route change, layout switch). Recover
      // a fresh reference instead of silently stalling forever.
      if (!document.contains(scroller)) {
        const recovered = await findScrollerWithRetry(4, 500);
        if (!recovered) {
          scrollerLost = true;
          break;
        }
        scroller = recovered;
      }

      if (i % 5 === 0 && detectRateLimitWarning()) {
        rateLimitHits++;

        if (rateLimitHits > MAX_RATE_LIMIT_BACKOFFS) {
          rateLimited = true;
          break;
        }

        chrome.runtime.sendMessage({
          type: 'MC_RATE_LIMIT',
          attempt: rateLimitHits,
          maxAttempts: MAX_RATE_LIMIT_BACKOFFS
        });

        await sleep(RATE_LIMIT_BACKOFF_MS);
        i--; // retry this step fresh rather than counting it as a scroll step
        continue;
      }

      const entries = captureEntries(scroller);
      const signature = signatureOf(entries);

      if (entries.length && signature !== lastSavedSignature) {
        snapshots.push(entries);
        lastSavedSignature = signature;
        window.__MC_COUNT__ = snapshots.reduce((sum, s) => sum + s.length, 0);
      }

      const beforeTop = scroller.scrollTop;
      const beforeHeight = scroller.scrollHeight;

      scroller.scrollBy(0, -Math.max(700, scroller.clientHeight * 1.3));

      let loaded = await waitForStableChange(scroller, beforeTop, beforeHeight, 4000);

      if (window.__MC_STOP_REQUESTED__) {
        stoppedEarly = true;
        break;
      }

      if (!loaded) {
        scroller.scrollBy(0, -Math.max(300, scroller.clientHeight * 0.5));
        loaded = await waitForStableChange(scroller, beforeTop, beforeHeight, 3000);
      }

      noMovementChecks = loaded ? 0 : noMovementChecks + 1;

      if (i % 5 === 0) {
        chrome.runtime.sendMessage({ type: 'MC_PROGRESS', count: snapshots.reduce((sum, s) => sum + s.length, 0) });
      }
    }

    if (!stoppedEarly && !rateLimited && !scrollerLost) {
      await waitUntilVisible();
      await sleep(1500);

      const lastEntries = captureEntries(scroller);
      if (lastEntries.length && signatureOf(lastEntries) !== lastSavedSignature) {
        snapshots.push(lastEntries);
        lastSavedSignature = signatureOf(lastEntries);
      }

      await sleep(1500);
      const veryLastEntries = captureEntries(scroller);
      if (veryLastEntries.length && signatureOf(veryLastEntries) !== lastSavedSignature) {
        snapshots.push(veryLastEntries);
      }
    }

    return { snapshots, stoppedEarly, rateLimited, scrollerLost, notFound: false };
  }

  function finalizeAndDownload(snapshots, meta) {
    const ordered = snapshots.slice().reverse();

    let result = [];
    for (const part of ordered) {
      result = result.length ? merge(result, part) : part;
    }

    const finalTextLines = [];
    for (const e of result) {
      if (e.text) finalTextLines.push(e.text);
      for (const src of e.imgs) finalTextLines.push('[εικόνα] ' + src);
    }
    const finalText = finalTextLines.join('\n');

    window.__MC_TEXT__ = finalText;
    window.__MC_ENTRIES__ = result;

    const chatName = detectChatName();
    const chatSafe = chatName ? sanitizeForFilename(chatName) : '';

    const blob = new Blob([finalText], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');

    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    a.href = url;
    a.download = OWNER_FILE_PREFIX + '-' + (chatSafe || 'Messenger-Synomilia') + '-' + stamp + '.txt';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);

    chrome.runtime.sendMessage({
      type: 'MC_DONE',
      lines: finalTextLines.length,
      text: finalText,
      entries: result,
      chatName: chatName || null,
      stoppedEarly: !!meta.stoppedEarly,
      rateLimited: !!meta.rateLimited,
      scrollerLost: !!meta.scrollerLost
    });
  }

  async function runCapture() {
    chrome.runtime.sendMessage({ type: 'MC_STARTED' });
    enableUnloadWarning();

    let attempt = await attemptCapture();

    if (attempt.notFound) {
      chrome.runtime.sendMessage({ type: 'MC_ERROR', error: 'Δεν βρέθηκε το παράθυρο της συνομιλίας.' });
      return;
    }

    // Total stall on the first try (zero messages collected, not a manual
    // stop, not a known rate-limit) — likely caught the page mid-render.
    // Give it one automatic second attempt before reporting anything.
    if (
      attempt.snapshots.length === 0 &&
      !attempt.stoppedEarly &&
      !attempt.rateLimited &&
      !attempt.scrollerLost
    ) {
      chrome.runtime.sendMessage({ type: 'MC_PROGRESS', count: 0, retrying: true });
      attempt = await attemptCapture();

      if (attempt.notFound) {
        chrome.runtime.sendMessage({ type: 'MC_ERROR', error: 'Δεν βρέθηκε το παράθυρο της συνομιλίας.' });
        return;
      }
    }

    finalizeAndDownload(attempt.snapshots, attempt);
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === 'MC_START') {
      if (window.__MC_RUNNING__) {
        chrome.runtime.sendMessage({ type: 'MC_ALREADY_RUNNING' });
        sendResponse({ ok: false, reason: 'already-running' });
        return;
      }

      window.__MC_RUNNING__ = true;
      window.__MC_STOP_REQUESTED__ = false;
      window.__MC_COUNT__ = 0;

      runCapture()
        .catch(err => {
          chrome.runtime.sendMessage({ type: 'MC_ERROR', error: String(err && err.message || err) });
        })
        .finally(() => {
          window.__MC_RUNNING__ = false;
          window.__MC_STOP_REQUESTED__ = false;
          disableUnloadWarning();
        });

      sendResponse({ ok: true });
      return;
    }

    if (msg.type === 'MC_STOP') {
      if (window.__MC_RUNNING__) {
        window.__MC_STOP_REQUESTED__ = true;
      }
      sendResponse({ ok: true });
      return;
    }

    if (msg.type === 'MC_STATUS') {
      sendResponse({
        running: !!window.__MC_RUNNING__,
        count: window.__MC_COUNT__ || 0
      });
      return;
    }
  });
})();
