const askSection = document.getElementById('askSection');
const noHint = document.getElementById('noHint');
const yesBtn = document.getElementById('yesBtn');
const noBtn = document.getElementById('noBtn');

const progressSection = document.getElementById('progressSection');
const status = document.getElementById('status');
const spinner = document.getElementById('spinner');
const stopBtn = document.getElementById('stopBtn');

const doneSection = document.getElementById('doneSection');
const doneStatus = document.getElementById('doneStatus');
const copyBtn = document.getElementById('copyBtn');
const copiedNote = document.getElementById('copiedNote');
const jsonBtn = document.getElementById('jsonBtn');
const htmlBtn = document.getElementById('htmlBtn');
const csvBtn = document.getElementById('csvBtn');
const txtBtn = document.getElementById('txtBtn');
const exportedNote = document.getElementById('exportedNote');

const OWNER_NAME = 'Alexandros Grigoratos';
const OWNER_FILE_PREFIX = OWNER_NAME.replace(/\s+/g, '-');

let capturedText = '';
let capturedEntries = [];
let capturedChatName = null;
let activeTabId = null;

function showSection(section) {
  [askSection, progressSection, doneSection].forEach(s => s.classList.add('hidden'));
  section.classList.remove('hidden');
}

function setProgress(count) {
  status.textContent = 'Συλλογή σε εξέλιξη... ' + count + ' μηνύματα συλλέχθηκαν.';
  status.className = '';
  spinner.classList.remove('hidden');
}

async function startCaptureOnTab(tabId) {
  status.textContent = 'Εκκίνηση συλλογής... μην αλλάξεις καρτέλα.';
  status.className = '';
  spinner.classList.remove('hidden');
  showSection(progressSection);

  chrome.tabs.sendMessage(tabId, { type: 'MC_START' }, () => {
    if (chrome.runtime.lastError) {
      status.textContent =
        'Δεν βρέθηκε το script στη σελίδα. Κάνε ανανέωση (F5) τη σελίδα του Messenger και ξαναδοκίμασε.';
      status.className = 'error';
      spinner.classList.add('hidden');
    }
  });
}

// On popup open, find the active tab and ask the content script whether a
// capture is already running there — so closing/reopening the popup mid-run
// resumes the progress view instead of resetting to the initial question.
(async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !/messenger\.com|facebook\.com/.test(tab.url || '')) return;

  activeTabId = tab.id;

  chrome.tabs.sendMessage(tab.id, { type: 'MC_STATUS' }, (response) => {
    if (chrome.runtime.lastError || !response) return;

    if (response.running) {
      setProgress(response.count || 0);
      showSection(progressSection);
    }
  });
})();

noBtn.addEventListener('click', () => {
  noHint.classList.remove('hidden');
});

yesBtn.addEventListener('click', async () => {
  noHint.classList.add('hidden');

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  if (!tab || !/messenger\.com|facebook\.com/.test(tab.url || '')) {
    status.textContent = 'Άνοιξε πρώτα μια συνομιλία στο messenger.com';
    status.className = 'error';
    spinner.classList.add('hidden');
    showSection(progressSection);
    return;
  }

  activeTabId = tab.id;
  startCaptureOnTab(tab.id);
});

stopBtn.addEventListener('click', () => {
  if (!activeTabId) return;

  status.textContent = 'Διακοπή... θα ολοκληρωθεί με ό,τι έχει συλλεχθεί μέχρι τώρα.';
  status.className = '';
  stopBtn.disabled = true;

  chrome.tabs.sendMessage(activeTabId, { type: 'MC_STOP' }, () => {
    if (chrome.runtime.lastError) {
      status.textContent = 'Δεν ήταν δυνατή η διακοπή — δοκίμασε ξανά.';
      status.className = 'error';
      stopBtn.disabled = false;
    }
  });
});

copyBtn.addEventListener('click', async () => {
  try {
    await navigator.clipboard.writeText(capturedText);
    copiedNote.classList.remove('hidden');
  } catch (e) {
    copiedNote.textContent = 'Το αντίγραφο απέτυχε — το αρχείο .txt έχει ήδη κατέβει.';
    copiedNote.classList.remove('hidden');
  }
});

// ---- Additional export formats, built from the structured entries the
// content script sent back with MC_DONE ----

function sanitizeForFilename(name, maxLen = 60) {
  return name
    .replace(/[^\p{L}\p{N}\-_. ]/gu, '')
    .trim()
    .replace(/\s+/g, '-')
    .slice(0, maxLen);
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
  }[c]));
}

function baseFilename(ext) {
  const chatSafe = capturedChatName ? sanitizeForFilename(capturedChatName) : '';
  const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
  return OWNER_FILE_PREFIX + '-' + (chatSafe || 'Messenger-Synomilia') + '-' + stamp + '.' + ext;
}

function downloadBlob(content, mime, filename) {
  const blob = new Blob([content], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
}

function buildJSON() {
  return JSON.stringify({
    exportedAt: new Date().toISOString(),
    chatName: capturedChatName,
    owner: OWNER_NAME,
    messageCount: capturedEntries.length,
    messages: capturedEntries.map((e, i) => ({
      index: i,
      text: e.text || '',
      images: e.imgs || []
    }))
  }, null, 2);
}

function buildHTML() {
  const title = 'Messenger — ' + (capturedChatName || 'Συνομιλία');

  const rows = capturedEntries.map(e => {
    const textHtml = e.text ? '<p>' + escapeHtml(e.text).replace(/\n/g, '<br>') + '</p>' : '';
    const imgsHtml = (e.imgs || [])
      .map(src => '<img src="' + escapeHtml(src) + '" loading="lazy" alt="">')
      .join('');
    return '<div class="msg">' + textHtml + imgsHtml + '</div>';
  }).join('\n');

  return '<!doctype html><html lang="el"><head><meta charset="utf-8">' +
    '<meta name="viewport" content="width=device-width, initial-scale=1">' +
    '<title>' + escapeHtml(title) + '</title><style>' +
    'body{font-family:-apple-system,BlinkMacSystemFont,"Helvetica Neue",Arial,sans-serif;' +
    'background:#f2f2f7;margin:0;padding:24px 16px;color:#1c1c1e;}' +
    '.wrap{max-width:640px;margin:0 auto;}' +
    'h1{font-size:20px;margin:0 0 4px;}' +
    '.note{font-size:12.5px;color:#6e6e73;background:#fff;border-radius:10px;padding:10px 14px;margin-bottom:16px;}' +
    '.msg{background:#fff;border-radius:14px;padding:10px 14px;margin-bottom:8px;box-shadow:0 1px 2px rgba(0,0,0,0.04);}' +
    '.msg p{margin:0;font-size:14px;line-height:1.5;white-space:pre-wrap;}' +
    '.msg img{max-width:100%;border-radius:10px;margin-top:8px;display:block;}' +
    '</style></head><body><div class="wrap">' +
    '<h1>' + escapeHtml(title) + '</h1>' +
    '<div class="note">Εξήχθη από τον Alexandros Grigoratos στις ' + escapeHtml(new Date().toLocaleString('el-GR')) +
    '. Οι εικόνες φορτώνονται απευθείας από τους αρχικούς συνδέσμους του Facebook — αν αυτοί λήξουν, ίσως σταματήσουν να εμφανίζονται.</div>' +
    rows + '</div></body></html>';
}

function buildCSV() {
  const esc = v => '"' + String(v).replace(/"/g, '""') + '"';
  const header = 'index,text,image_urls\n';
  const lines = capturedEntries.map((e, i) =>
    [i, e.text || '', (e.imgs || []).join(';')].map(esc).join(',')
  );
  return header + lines.join('\n');
}

function showExportedNote(label) {
  exportedNote.textContent = label + ' κατέβηκε ✓';
  exportedNote.classList.remove('hidden');
}

txtBtn.addEventListener('click', () => {
  downloadBlob(capturedText, 'text/plain;charset=utf-8', baseFilename('txt'));
  showExportedNote('TXT');
});

jsonBtn.addEventListener('click', () => {
  downloadBlob(buildJSON(), 'application/json;charset=utf-8', baseFilename('json'));
  showExportedNote('JSON');
});

htmlBtn.addEventListener('click', () => {
  downloadBlob(buildHTML(), 'text/html;charset=utf-8', baseFilename('html'));
  showExportedNote('HTML');
});

csvBtn.addEventListener('click', () => {
  downloadBlob(buildCSV(), 'text/csv;charset=utf-8', baseFilename('csv'));
  showExportedNote('CSV');
});

chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === 'MC_PROGRESS') {
    if (msg.retrying) {
      status.textContent = 'Δεν βρέθηκε περιεχόμενο στην πρώτη προσπάθεια — ξαναδοκιμάζει αυτόματα...';
      status.className = '';
      spinner.classList.remove('hidden');
      return;
    }
    setProgress(msg.count);
    stopBtn.disabled = false;
  } else if (msg.type === 'MC_RATE_LIMIT') {
    status.textContent =
      'Το Facebook εμφάνισε προειδοποίηση φόρτωσης — γίνεται παύση (' +
      msg.attempt + '/' + msg.maxAttempts + ')...';
    status.className = 'warning';
    spinner.classList.remove('hidden');
  } else if (msg.type === 'MC_DONE') {
    capturedText = msg.text || '';
    capturedEntries = msg.entries || [];
    capturedChatName = msg.chatName || null;

    if (msg.rateLimited) {
      doneStatus.textContent = 'Διακόπηκε λόγω περιορισμού από το Facebook — αποθηκεύτηκαν ' + msg.lines + ' γραμμές.';
    } else if (msg.scrollerLost) {
      doneStatus.textContent = 'Η σελίδα άλλαξε απροσδόκητα — αποθηκεύτηκαν ' + msg.lines + ' γραμμές.';
    } else if (msg.stoppedEarly) {
      doneStatus.textContent = 'Διακόπηκε — αποθηκεύτηκαν ' + msg.lines + ' γραμμές μέχρι εκείνο το σημείο.';
    } else {
      doneStatus.textContent = 'Έτοιμο! ' + msg.lines + ' γραμμές αποθηκεύτηκαν σε αρχείο .txt.';
    }

    copiedNote.classList.add('hidden');
    exportedNote.classList.add('hidden');
    stopBtn.disabled = false;
    showSection(doneSection);
  } else if (msg.type === 'MC_ERROR') {
    status.textContent = 'Σφάλμα: ' + msg.error;
    status.className = 'error';
    spinner.classList.add('hidden');
    showSection(progressSection);
  } else if (msg.type === 'MC_ALREADY_RUNNING') {
    status.textContent = 'Η συλλογή τρέχει ήδη σε αυτή τη σελίδα.';
    status.className = 'error';
    spinner.classList.add('hidden');
    showSection(progressSection);
  }
});
